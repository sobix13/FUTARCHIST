"""FUTARCHIST public entry point."""
__version__='2.1.2'
